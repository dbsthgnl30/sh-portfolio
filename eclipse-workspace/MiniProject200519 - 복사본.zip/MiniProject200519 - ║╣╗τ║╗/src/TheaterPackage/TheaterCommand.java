package TheaterPackage;

import java.util.Scanner;

public interface TheaterCommand {
public abstract void execute(Scanner sc);
}
