package TheaterPackage;

public class TheaterMainEx {
public static void main(String[] args) {
	new TheaterProcess();
}
}
