package Total;

public class TotalMainEx {
	public static void main(String[] args) {
		new TotalProcess();
	}
}
