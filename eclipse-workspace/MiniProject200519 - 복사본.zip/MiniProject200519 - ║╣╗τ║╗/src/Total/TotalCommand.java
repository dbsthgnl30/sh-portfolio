package Total;

import java.util.Scanner;

public interface TotalCommand {
	void execute(Scanner sc);
}
