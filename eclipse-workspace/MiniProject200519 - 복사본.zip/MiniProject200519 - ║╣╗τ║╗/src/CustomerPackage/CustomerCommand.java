package CustomerPackage;

import java.util.Scanner;

public interface CustomerCommand {
	void execute(Scanner sc);
}
