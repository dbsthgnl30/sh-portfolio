package CustomerPackage;

public class CustomerMain {
public static void main(String[] args) {
	 new CustomerProcess();
}
}
