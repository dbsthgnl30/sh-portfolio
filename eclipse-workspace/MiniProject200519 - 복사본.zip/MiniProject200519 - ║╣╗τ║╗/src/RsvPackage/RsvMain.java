package RsvPackage;

public class RsvMain {
public static void main(String[] args) {
	 new RsvProcess();
}
}
