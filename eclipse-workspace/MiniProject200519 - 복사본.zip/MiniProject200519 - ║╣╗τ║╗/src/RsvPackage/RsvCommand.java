package RsvPackage;

import java.util.Scanner;

public interface RsvCommand {
	void execute(Scanner sc);
}
