package MoviePackage;

public class MovieMainEx {
	public static void main(String[] args) {
		new MovieProcess();
	}
}
