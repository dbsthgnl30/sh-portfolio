package MoviePackage;

import java.util.Scanner;

public interface MovieCommand {
	void execute(Scanner sc);
}
